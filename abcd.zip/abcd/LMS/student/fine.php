<?php
$idate = date_create($value['iDate']);
$current_date = date_create(date("Y-m-d"));
$diff = date_diff($idate, $current_date);
$dtdiff = number_format($diff->format("%R%a"));
// echo $dtdiff;
// echo date_format($current_date,"Y-m-d");
if($dtdiff > 14){
    echo "Rs. ".(($dtdiff-14)*3)."/-";
}else {
    echo 'NIL';
}
?>