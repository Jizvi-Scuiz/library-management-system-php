<?php 
$issue_date = date_create($value['iDate']);

date_add($issue_date,date_interval_create_from_date_string("14 days"));
echo date_format($issue_date,"Y-m-d");

?>