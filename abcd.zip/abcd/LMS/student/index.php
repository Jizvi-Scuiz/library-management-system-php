<?php session_start(); ?>
<?php include "header.php" ?>
<?php include "function.php" ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    // echo "<pre>"; print_r($_SESSION); die;
?>
<?php 
$st_data = get_data($user);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="css/table.css">

</head>
<body>
    <div class="container">
    <h5><center>Your Details</center></h5>
                <!-- <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>             -->
                <table class="table">
                        <thead>
                            <tr>                                
                                <th>ID</th>
                                <th>Name</th>
                                <th>Gender</th>
                                <th>Semester</th>
                                <th>Subject</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>City</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if($st_data){
                                foreach($st_data as $key=>$value){                                                                       
                                    ?>
                                    <tr id="book">
                                        <td><?php echo $value['student_id']?></td>
                                        <td><?php echo $value['name']?></td>
                                        <td><?php echo $value['gender']?></td>
                                        <td><?php echo $value['semester']?></td>
                                        <td><?php echo $value['subject']?></td>
                                        <td><?php echo $value['phone']?></td>
                                        <td><?php echo $value['email']?></td>
                                        <td><?php echo $value['city']?></td>

                                    </tr><?php                                     
                                }
                            }?>
                        </tbody>
                    </table>
                </div>
                <br>
                
        <?php include "Records.php" ?>
        <?php include "available.php" ?>
</body>
</html>

<?php include "footer.php" ?>