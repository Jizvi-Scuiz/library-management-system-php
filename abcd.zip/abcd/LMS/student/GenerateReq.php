<?php session_start(); ?>
<?php include "function.php"?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    // echo "<pre>"; print_r($_SESSION); die;
?>
<?php
// echo $_POST['studid'];
    // echo "<pre>"; print_r($_POST); die;
    $book_isbn = $_POST['bookid'];
    $book_id = getId($book_isbn)['book_id'];
    $stud_id = $_POST['studid'];
    // echo $book_id;
    // echo $book_isbn; die;
    $x = genReq($book_isbn,$book_id,$stud_id);
    if($x){
        // header('location:index.php');
        echo "<center>Request Generated</center>";  
        echo "<center><a href='logout.php'>Logout</a></center>";
    }
?>