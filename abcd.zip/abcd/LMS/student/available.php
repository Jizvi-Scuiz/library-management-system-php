
<?php echo "<br><center><h5>Available Books: </h5></center> </p> ";

    // echo "<pre>"; print_r($st_data[0]); die;
    $sem = $st_data[0]['semester'];
    $sub = $st_data[0]['subject'];
    $x = GetBooks($sem, $sub);
    // echo "<pre>"; print_r($x); die;


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/table.css">

</head>
<body>
<div class="container">
                    <table class="table" id="books">
                        <thead>
                            <tr>                                
                                <th>ISBN</th>
                                <th>Book Name</th>
                                <th>Author Name</th>
                                <th>About Book</th>
                                <th>Publisher</th>
                                <th>Generate req. </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php     
                            foreach($x as $key => $value){
                                $flag[$key] = checkIfIssued($value['book_id']);
                                if($flag[$key]==0){
                                    // echo $value['name'];                                
                            ?>
                                    <tr>
                                        <td><?php echo $value['ISBN'] ?></td>
                                        <td><?php echo $value['name']?></td>
                                        <td><?php echo $value['author']?></td>
                                        <td><?php echo $value['description']?></td>
                                        <td><?php echo $value['publisher']?></td>
                                        <td > 
                                            <?php 
                                            $req = getReq($value['book_id']);
                                            // echo "<pre>"; print_r($req);

                                            ?> 
                                            <?php if($req!=NULL) {
                                                echo "Request Generated";?>
                                            <?php 
                                            }
                                            else
                                            { ?>
                                                <button class="btn btn-dark" name="button" id="btn1" onclick="GenReq(<?php echo $value['ISBN']; ?>)">Request</button>
                                            <?php } ?>                                       
                                        </td>
                                    </tr><?php                                     
                                }
                            }

                            ?>
                        </tbody>
                    </table>
                </div>
                <p id="show"></p>
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">
	function GenReq(id){
		$.ajax({
	        url: "GenerateReq.php",
	        method: "POST",
	        datatype: "HTML",
	        data: {
	          bookid:id,
              studid:<?php echo $user ?>
	        },
	        success: function(x){
	          $("#show").html(x),
              $("#books").hide()
	        }
	    });	
	}
</script>