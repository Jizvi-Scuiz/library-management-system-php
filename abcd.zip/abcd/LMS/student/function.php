<?php 
include "connect.php";
?>


<?php

function get_data($id){
    $query = "SELECT * FROM student WHERE student_id = $id";
    $conn = db_conn();
    $res = mysqli_query($conn,$query);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;
}
function GetRecords($id){
    $que = "SELECT * FROM `records` WHERE student_id='$id'";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;    
}

function BookInfo($id){
    $que = "SELECT * FROM `booklist` WHERE book_id='$id'";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;
}
function GetBooks($sem,$sub){
    $que = "SELECT book_id, ISBN, name, author, description, pub_year, price, publisher FROM booklist WHERE sem=$sem AND subject='$sub'";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;
}
function checkIfIssued($id){
    $que = "SELECT book_id FROM `records` WHERE 1";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    $flag=0;
    // echo "<pre>"; print_r($data[0]);die;
    foreach($data as $key => $value){
        if($value['book_id']==$id){
            $flag++;
        }
    }
    return $flag;
}

function genReq($book_isbn,$book_id,$stud_id){
    $que = "INSERT INTO `requests` (`ISBN`, `book_id`, `student_id`) VALUES ('$book_isbn','$book_id', '$stud_id')";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    return $res;
}

function getReq($book_id){
    // echo $book_id; die;
    $que = "SELECT * FROM requests WHERE book_id = '$book_id' ";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    if($res){
        $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
        return $data;
    }
}

function getID($id)
{
    $que = "SELECT book_id FROM `booklist` WHERE ISBN = $id";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data[0];  
}

?>