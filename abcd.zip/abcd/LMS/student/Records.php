<?php 
$books = GetRecords($user);
foreach($books as $key=>$value){
    $info[$key]=BookInfo($value['book_id']);
    
}
// echo "<pre>"; print_r($info); die;
    // echo "<pre>"; print_r($books); die;
$count=0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/table.css">

</head>
<body>
    
                <div class="container">
                    <h5><center>Books Issued</center></h5>
                    <table class="table">
                        <thead>
                            <tr>                                
                                <th>Book Name</th>
                                <th>Author Name</th>
                                <th>Issue Date</th>
                                <th>(To Avoid Fine)<br>Return Within</th>
                                <th>Fine</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if($books){
                                foreach($books as $key=>$value){
                                    $count++;
                                    ?>
                                    <tr>
                                        <td><?php echo $info[$key][0]['name'] ?></td>
                                        <td><?php echo $info[$key][0]['author']?></td>
                                        <td><?php echo $value['iDate']?></td>
                                        <td><?php include "date.php"; ?></td>
                                        <td><?php include "fine.php" ?></td>
                                    </tr><?php                                     
                                }
                            }?>
                        </tbody>
                    </table>
                </div>
                <?php 
                if($count>2){
                    echo "<h5><center>You Have Already Issued 3 Books<center></h5>"; 
                    include "footer.php"; die;
                }
                
                ?>


</body>
</html>