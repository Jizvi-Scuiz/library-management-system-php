<?php 
include "connect.php";
?>
<?php 

function GetIds(){
    $query = "SELECT student_id FROM student WHERE 1";
    $conn = db_conn();
    $res = mysqli_query($conn,$query);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;
}
function get_Student_data($id){
    $query = "SELECT name, password, student_id FROM student WHERE student_id = $id";
    $conn = db_conn();
    $res = mysqli_query($conn,$query);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data[0];
}

?>
