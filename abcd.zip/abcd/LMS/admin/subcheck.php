<?php session_start() ?>
<?php include 'function.php' ?>
<?php

$isbn = $_SESSION['isbn'];
$sub = $_POST['subject'];
$sem = $_SESSION['sem'];
$x = checkall($isbn, $sem, $sub);
    if($x){
        echo "Book Exists";
        die;
    }
// $_SESSION['sub'] = $sub;

if (!isset($_SESSION['isbn'])||!isset($_SESSION['sem']))
{
    echo "Eto vull korle hoy 😕😕😕<br> Aage toh ISBN r Semester ta enter korte hbe"; die;
}
else{
    $isbn = $_SESSION['isbn'];
    $sem = $_SESSION['sem'];

    $a = checkall($isbn, $sem, $sub);
    if($a){
        echo "Book Exists";
        $flag=0;
    }
    
    else{
        echo "Seems like a new Book<br>head on to add more details";
        $flag = 1;
    }
    
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <body>
        <?php if($flag==1){?>
            <div class="col-md-12">
                <input class="form-control" type="text" name="name" placeholder="Book Name" required onchange="check(this.value)" >
                <div class="valid-feedback">Book name field is valid!</div>
                <div class="invalid-feedback">Book name field cannot be blank!</div>
            </div>
            <div class="col-md-12">
                <input class="form-control" type="text" name="auth" placeholder="Author Name" required >
                <div class="valid-feedback">Author field is valid!</div>
                <div class="invalid-feedback">Author field cannot be blank!</div>
            </div>
            <div class="col-md-12">
                <input class="form-control" type="text" name="pgs" placeholder="No of Pages" required >
                <div class="valid-feedback">Pages field is valid!</div>
                <div class="invalid-feedback">Pages field cannot be blank!</div>
            </div>
            <div class="col-md-12">
                <input class="form-control" type="text" name="desc" placeholder="Book Desc" required >
                <div class="valid-feedback">Desc field is valid!</div>
                <div class="invalid-feedback">Desc field cannot be blank!</div>
            </div>
            
            <div class="col-md-12">
                <input class="form-control" type="text" name="publisher" placeholder="Publisher" required >
                <div class="valid-feedback">Publisher field is valid!</div>
                <div class="invalid-feedback">Publisher field cannot be blank!</div>
            </div>
            <div class="col-md-12">
                <input class="form-control" type="text" name="pby" placeholder="Publish Year" required >
                <div class="valid-feedback">Year field is valid!</div>
                <div class="invalid-feedback">Year field cannot be blank!</div>
            </div>
            <div class="col-md-12">
                <input class="form-control" type="text" name="pr" placeholder="Price" required  >
                <div class="valid-feedback">Price field is valid!</div>
                <div class="invalid-feedback">Price field cannot be blank!</div>
            </div>
            
        <?php }
        ?>
    </body>
    </html> <?php

}
?>
