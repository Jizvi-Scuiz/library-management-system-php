<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>

<?php include "function.php"; ?>
<?php 
$bookid = $_POST['bookid'];
// echo $bookid; die;
$studentid = $_POST['studid'];
$phn = GetPhone($studentid)['phone'];
$date = date("Y-m-d");
$ifreq = ifReq($bookid);
$bookisbn = getIsbn($bookid);
// echo "<pre>"; print_r($isbn); 
$isbn = $bookisbn[0]['ISBN'];

// echo $ifreq; die;
if($ifreq){
    if(deleteReq($bookid)){
        echo "Request Deleted & ";
    }
}
else{
    echo "";
}

// echo $date;
// echo $studentid; 
// echo $phn;
// echo $bookid; 
// echo $isbn, die;

$x = BookIssued($studentid,$phn,$isbn,$bookid,$date);

if($x){
    echo "Book Issued";
    echo "<br><a href='index.php'>Home</a>";
}

?>
