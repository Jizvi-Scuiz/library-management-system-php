<?php session_start() ?>
<?php include 'function.php' ?>
<?php

$sem = $_POST['semester'];
$_SESSION['sem'] = $sem;
?>