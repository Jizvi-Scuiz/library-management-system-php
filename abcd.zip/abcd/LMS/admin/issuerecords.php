<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>

<?php include "header.php"?>
<?php include "function.php"?>
<?php $rec = GetRec(); 
// echo "<pre>"; print_r($rec); die;

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/table.css">
</head>
<body>
<div class="container">
            <!-- <h2>Basic Table</h2> -->
            <!-- <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>             -->
                <table class="table">
                    <thead>
                        <tr>
                            <th>ISBN</th>
                            <th colspan="2">Issued By</th>
                            <th>Date</th>
                        </tr>
                        <tr>
                            <th></th>
                            <th>student ID</th>
                            <th>Phone NO</th>
                            <th></th>
                        </tr>
                    </thead>
                <tbody>
                    <?php if($rec){
                        foreach($rec as $key => $value){ ?>
                            <tr>
                                <td><?php echo $value['book_isbn']?></td>
                                <td><?php echo $value['student_id']?></td>
                                <td><?php echo $value['phone_no']?></td>
                                <td><?php echo $value['iDate'] ?></td>
                            </tr><?php 
    
                        }
                    }?>
                </tbody>
             </table>
        </div>
</body>
</html>


<?php include "footer.php"?>