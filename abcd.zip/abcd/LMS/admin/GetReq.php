
<?php include "function.php" ?>
<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>
<?php 

$x = getReq();
    			// echo "<pre>"; print_r($x); die;
foreach($x as $key => $value){
    $b_id = $value['book_id'];
    $s_id = $value['student_id'];
    $bk[$key] = ShowBooks($b_id);
    $st[$key] = ShowStudent($s_id);
}
// foreach ($x as $key => $value){
//     echo "<pre>"; print_r($st[$key]).'<br>';
//     echo "<pre>"; print_r($bk[$key][0]).'<br>';
// }die;
// echo "<pre>"; print_r($bk); die;
// echo "<pre>"; print_r($st); die;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/table.css">

</head>
<body>
<p id="del"></p>
<p id="issued"></p>
<div class="container" id="books">
                <!-- <h2>Basic Table</h2> -->
                <!-- <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>             -->
                    <table class="table" id="tbl">
                        <thead>
                            <tr>                                
                                <th>ISBN</th>
                                <th>Book Name</th>
                                <th>Author</th>
                                <th>Student ID</th>
                                <th>Student Name</th>
                                <th>Semester</th>
                                <th>Subject</th>
                                <th>Phone</th>
                                <th>Issue</th>
                                <th>Cancel</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php  foreach ($x as $key => $value){?>                         
                            <tr>
                                <td><?php echo $bk[$key][0]['ISBN']?></td>
                                <td><?php echo $bk[$key][0]['name']?></td>
                                <td><?php echo $bk[$key][0]['author']?></td>
                                <td><?php echo $st[$key]['student_id']?></td>
                                <td><?php echo $st[$key]['name']?></td>
                                <td><?php echo $st[$key]['semester']?></td>
                                <td><?php echo $st[$key]['subject']?></td>
                                <td><?php echo $st[$key]['phone']?></td>
                                <td>
                                <?php $stid = $st[$key]['student_id']; 
                                    if(no_of_books($stid)){?>
                                    <button class="btn btn-success" name="button" id="btn1" onclick="issue(<?php echo $bk[$key][0]['book_id']; ?>, 
                                    <?php echo $st[$key]['student_id']?>)" >Issue</button> 
                                    <?php 
                                }?></td>
                                <td> <button class="btn btn-danger" name="button" id="btn1" onclick="del(<?php echo $bk[$key][0]['book_id']; ?>)">Cancel</button> </td>
                            </tr><?php } ?>
                        </tbody>
                    </table>
                </div>
                

</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">
	function issue(id1, id2) {
		$.ajax({
	        url: "issued.php",
	        method: "POST",
	        datatype: "HTML",
	        data: {
	          bookid:id1,
              studid:id2
            //   studid:$id
	        },
	        success: function(x){
	          $("#issued").html(x);
              $("#books").hide();
	        }
	    });	
	}
</script>
<script type="text/javascript">
	function del(id1) {
		$.ajax({
	        url: "del.php",
	        method: "POST",
	        datatype: "HTML",
	        data: {
	          bookid:id1,
            //   studid:$id
	        },
            success: function(x){
	          $("#del").html(x);
	          $("#tbl").hide();
	        }
	    });	
	}
</script>
