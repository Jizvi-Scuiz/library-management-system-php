
<?php include "function.php" ?>
<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>

<?php include "header.php"; ?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Heroic Features - Start Bootstrap Template</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        
    </head>
    <body>
        
        <!-- Header-->
        <header class="py-5">
            <div class="container px-lg-5">
                <div class="p-4 p-lg-5 bg-light rounded-3 text-center">
                    <div class="m-4 m-lg-5">
                        <h4 class="display-5 fw-bold">Welcome to Science Library</h4>
                        <h4>You are logged into the admin portal</h4>
                        <p class="fs-4">Manage your library with the provided features</p>
                        <a class="btn btn-primary btn-lg" href="addbook.php">Add a new Book</a><br><br>
                        <?php 
                        $req = getReq();
                        if($req){
                        ?>
                        <button class="btn btn-primary btn-lg" id="btnx" onclick="ShowReq()">Requests Waiting Approval</button><br><br>
                        <?php } ?>
                        <p id="req"></p>
                        <center><?php if(isset($_GET['msg'])){
                            echo "<br>".$_GET['msg'];
                        }?></b></center>
                    </div>
                </div>
            </div>
        </header>
        <!-- Page Content-->
        <section class="pt-4">
            
            <div class="container px-lg-5">
                <!-- Page Features-->
                <div class="row gx-lg-5">
                    <div class="col-lg-6 col-xxl-4 mb-5">
                        <div class="card bg-light border-0 h-100">
                            <div class="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                            <a href="search.php"><div class="feature bg-primary bg-gradient text-white rounded-3 mb-4 mt-n4"><i class="bi bi-collection"></i></div>
                                <h2 class="fs-4 fw-bold">Issue Book</h2>
                                <p class="mb-0">Issue book to a student</p></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-xxl-4 mb-5">
                        <div class="card bg-light border-0 h-100">
                            <div class="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                            <a href="showBooks.php"><div class="feature bg-primary bg-gradient text-white rounded-3 mb-4 mt-n4"><i class="bi bi-cloud-download"></i></div>
                                <h2 class="fs-4 fw-bold">Show</h2>
                                <p class="mb-0">Show All Books Added to library</p></a>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="col-lg-6 col-xxl-4 mb-5">
                        <div class="card bg-light border-0 h-100">
                            <div class="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                            <a href="return.php"><div class="feature bg-primary bg-gradient text-white rounded-3 mb-4 mt-n4"><i class="bi bi-bootstrap"></i></div>
                                <h2 class="fs-4 fw-bold">Return or Renew</h2>
                                <p class="mb-0">Return or Renewal of an issue</p></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-xxl-4 mb-5">
                        <div class="card bg-light border-0 h-100">
                            <div class="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                            <a href="issuerecords.php"><div class="feature bg-primary bg-gradient text-white rounded-3 mb-4 mt-n4"><i class="bi bi-patch-check"></i></div>
                                <h2 class="fs-4 fw-bold">Records</h2>
                                <p class="mb-0">Show All Issued Records</p></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <p id="#issued"></p>
        <p id="#show"></p>
    </body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">
	function ShowReq() {
		$.ajax({
	        url: "GetReq.php",
	        method: "POST",
	        datatype: "HTML",
	        success: function(x){
	          $("#req").html(x)
            //   $("#btnx").hide();
	        }
	    });	
	}
</script>

<?php include "footer.php"; ?>