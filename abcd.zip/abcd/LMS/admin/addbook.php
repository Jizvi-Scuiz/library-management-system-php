<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>

<?php include "header.php"?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=0.8">
    <title>Add A New Book</title>
    <link rel="stylesheet" href="css/form1.css">
    
</head>
<body>
    <div class="form-body"> 
        <div class="row">
            <div class="form-holder">
                <div class="form-content">
                    <div class="form-items">
                        <h3><font color="yellow">Add a new Book </font></h3>
                        <p>Fill in the details of the book Below<br>
                        <!-- Add ISBN, Semester and Subject <font color="red"> serially as presented</font><br>
                        <font color="orange">Don't Overrite these details </font>.<br>Incase of mistake <a href="addbook.php" >Click Here</a></p> -->
                        
                        <form action="validate.php?id=Add" method="POST" class="requires-validation" novalidate>

                            <div class="col-md-12">
                               <input class="form-control" type="text" name="isbn" placeholder="ISBN" id="isbn" required onchange="check(this.value)" >
                               <div class="valid-feedback">ISBN field is valid!</div>
                               <div class="invalid-feedback">ISBN field cannot be blank!</div>
                            </div>


                           <div class="col-md-12">
                                <select name="semester" class="form-select mt-3" id="sem" required onchange="check1(this.value)" oninput="hide()">
                                      <option selected disabled value="">Semester</option>
                                      <option value="1">Sem 1</option>
                                      <option value="2">Sem 2</option>
                                      <option value="3">Sem 3</option>
                                      <option value="4">Sem 4</option>
                                      <option value="5">Sem 5</option>
                                      <option value="6">Sem 6</option>
                               </select>
                                <div class="valid-feedback">You selected a Semester!</div>
                                <div class="invalid-feedback">Please select a Semester!</div>
                           </div>
                           <div class="col-md-12">
                                <select name="subject" class="form-select mt-3" required onchange="check2(this.value)" oninput="hide1()">
                                      <option selected disabled value="" >Subject</option>
                                      <option value="phy">Physics</option>
                                      <option value="chem">Chemistry</option>
                                      <option value="com">Computer</option>
                                      <option value="bio">Biology</option>
                                      <option value="math">Mathematics</option>
                               </select>
                                <div class="valid-feedback">You selected a Subject!</div>
                                <div class="invalid-feedback">Please select a Subject!</div>
                           </div>
                        <br>

                           <!-- <div class="col-md-12">
                              <input class="form-control" type="password" name="password" placeholder="Password" required>
                               <div class="valid-feedback">Password field is valid!</div>
                               <div class="invalid-feedback">Password field cannot be blank!</div>
                           </div> -->
                            <p id="ISBNcheck">Enter Details of a New Book</p>
                            <div class="form-button mt-3">
                                <button name="addBook" id="submit" type="submit" class="btn btn-primary">Add Details</button>
                            </div>
                        </form>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <center><h4> <font color="yellow">  In case of any problem in the form<br>
                        <a href="addbook.php">Click Here</a><br> </font></h4><br></center>
    <center><h6><font color="red">  Go Back<br> </font> <a href="index.php">Home</a><br></h6></center>
    
    <?php include "footer.php";?>
</body>
</html>

<script src="js/form1.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">
	function check(isbn) {
		$.ajax({
	        url: "ISBNcheck.php",
	        method: "post",
	        datatype: "HTML",
	        data: {
                bookid:isbn
	        },
	        success: function(x){
	          $("#show").html(x);
	        }
	    });	
	}
</script>
<script type="text/javascript">
	function check1(sem) {
		$.ajax({
	        url: "semcheck.php",
	        method: "POST",
	        datatype: "HTML",
	        data: {
                semester:sem
	        },
	        // success: function(x){
	        //   $("#display").html(x);
	        // }
	    });	
	}
</script>
<script type="text/javascript">
	function check2(sub) {
		$.ajax({
	        url: "subcheck.php",
	        method: "post",
	        datatype: "HTML",
	        data: {
                subject:sub
	        },
	        success: function(x){
	          $("#ISBNcheck").html(x);
	        }
	    });	
	}

</script>