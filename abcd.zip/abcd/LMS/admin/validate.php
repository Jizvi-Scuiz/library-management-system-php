<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
?>

<?php include "function.php"?>
<?php include "header.php"?>


<?php
if(isset($_POST['addBook'])){
    // echo "<pre>"; print_r($_POST);die;
    $isbn = $_POST['isbn'];
    $sem = $_POST['semester'];
    $sub = $_POST['subject'];
    $name = $_POST['name'];
    $author = $_POST['auth'];
    $page = $_POST['pgs'];
    $description = $_POST['desc'];
    $price = $_POST['pr'];
    $publisher = $_POST['publisher'];
    $pbyr = $_POST['pby'];
    $flag=0;
    if($isbn!=NULL && $sem!=NULL && $sub!=NULL && $name!=NULL && $author!=NULL && $page!=NULL && $description!=NULL && $publisher!=NULL && $price!=NULL && $pbyr!=NULL){
        $flag+=1;
    }
    if(!is_numeric($name)&&!is_numeric($author)&&!is_numeric($publisher)){
        $flag+=1;
    }
    if(is_numeric($page)&&is_numeric($price)&&is_numeric($pbyr)&&(strlen($pbyr)<=5)&&(strlen($page)<5)&&(strlen($price)<6)&&((int)$pbyr<=2022)){
        $flag+=2;
    }
    // echo $flag."<br>";
    // echo $_GET['id']; die;
    if($flag==4 && ($_GET['id'] == "Add")){
        $add = addBook($isbn,$sem,$sub,$name,$author,$page,$description,$pbyr,$price,$publisher);
        if($add){
            header('location:index.php?msg="Book Added Succesfully"');
            $_SESSION['isbn'] = "";
            $_SESSION['sem'] = "";
        }
        else{
            // echo "<pre>"; print_r($_POST);die;
            echo "Data Base Jhar kheye geche";
        }
    }
    elseif($flag!=4 && ($_GET['id'] == "Add")) {
        // echo $flag.'<br><br>';
        // echo $_GET['id'];
        header('location:index.php?msg="Ki J koro ki jani 🥲🥲"');
        // echo "<pre>"; print_r($_POST);die;
    }
    elseif($flag==4 && (is_numeric($_GET['id']))){
        $update = UpdBook($isbn,$sem,$sub,$name,$author,$page,$description,$pbyr,$price,$publisher);
        if($update){
            header('location:index.php?msg=Update Succesfull');
            // echo "Update Succesfull";
        }
        else{
            echo "Vullll Hoyeche";
        }
    }
    else{
        header('location:index.php?msg=Erokom Vul vall kaaj kokrle hoy 😏<br>company theke ber kore debe toh 🥲');
    }
   
}

?>


<?php include "footer.php";?>