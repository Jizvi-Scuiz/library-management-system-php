<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>

<?php include "function.php"?>
<?php include "header.php"?>
<?php
$id = $_GET['id'];
$var=EditBooks($id);
// echo "<pre>"; print_r($var); die;
// var_dump($var);die;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=0.8">
    <title>Add A New Book</title>
    <link rel="stylesheet" href="css/form1.css">
</head>
<body>
    <div class="form-body"> 
        <div class="row">
            <div class="form-holder">
                <div class="form-content">
                    <div class="form-items">
                        <h3>Update Book</h3>
                        <p>ISBN: <?php echo $id ;?></p>
                        <form action="validate.php?id=<?php echo $id ;?>" method="POST" class="requires-validation" novalidate>

                            <div class="col-md-12">
                               <input class="form-control" type="hidden" name="isbn" value="<?php echo $id; ?>" >
                            </div>


                           <div class="col-md-12">
                           <select name="semester" class="form-select mt-3" required>
                                      <option selected value="<?php echo $var['sem'];?>"><?php echo $var['sem'];?></option>
                                      <option value="1">Sem 1</option>
                                      <option value="2">Sem 2</option>
                                      <option value="3">Sem 3</option>
                                      <option value="4">Sem 4</option>
                                      <option value="5">Sem 5</option>
                               </select>
                           <label for="semester">Semester: </label>     

                                <div class="valid-feedback">You selected a Semester!</div>
                                <div class="invalid-feedback">Please select a Semester!</div>
                           </div>
                           <div class="col-md-12">
                                <select name="subject" class="form-select mt-3" required>
                                      <option selected value="<?php echo $var['subject'];?>" ><?php echo $var['subject'];?></option>
                                      <option value="phy">Physics</option>
                                      <option value="chem">Chemistry</option>
                                      <option value="com">Computer</option>
                                      <option value="bio">Biology</option>
                                      <option value="math">Mathematics</option>
                               </select>
                            <label for="subject">Subject</label>

                                <div class="valid-feedback">You selected a Subject!</div>
                                <div class="invalid-feedback">Please select a Subject!</div>
                           </div>
                        <div class="col-md-12">
            
            <input class="form-control" type="text" name="name" placeholder="Book Name" required value="<?php echo trim($var['name'], " ");?> " >
            <label for="name">Book Name:</label>
            <div class="valid-feedback">Book name field is valid!</div>
            <div class="invalid-feedback">Book name field cannot be blank!</div>
        </div>
        <div class="col-md-12">
            <input class="form-control" type="text" name="auth" placeholder="Author Name" required  value="<?php echo $var['author'];?> ">
            <label for="auth">Author name: </label>
            <div class="valid-feedback">Author field is valid!</div>
            <div class="invalid-feedback">Author field cannot be blank!</div>
        </div>
        <div class="col-md-12">
            <input class="form-control" type="text" name="pgs" placeholder="No of Pages" required value="<?php echo $var['pages'];?> ">
            <label for="pgs">Pages:</label>
            <div class="valid-feedback">Pages field is valid!</div>
            <div class="invalid-feedback">Pages field cannot be blank!</div>
        </div>
        <div class="col-md-12">
            <input class="form-control" type="text" name="desc" placeholder="Book Desc" required value="<?php echo $var['description'];?> ">
            <label for="desc">Description: </label>
            <div class="valid-feedback">Description field is valid!</div>
            <div class="invalid-feedback">Description field cannot be blank!</div>
        </div>
        
        <div class="col-md-12">
            <input class="form-control" type="text" name="publisher" placeholder="Publisher" required value="<?php echo trim($var['publisher'], " ");?> ">
            <label for="pubillsher">Pubillsher</label>
            <div class="valid-feedback">Publisher field is valid!</div>
            <div class="invalid-feedback">Publisher field cannot be blank!</div>
        </div>
        <div class="col-md-12">
            <input class="form-control" type="text" name="pby" placeholder="Publish Year" required value="<?php echo trim($var['pub_year']);?> ">
            <label for="pby">Publish Year:</label>
            <div class="valid-feedback">Publish Year field is valid!</div>
            <div class="invalid-feedback">Publish Year field cannot be blank!</div>
        </div>
        <div class="col-md-12">
            <input class="form-control" type="text" name="pr" placeholder="Price" required value="<?php echo $var['price'];?> " >
            <label for="pr">Price:</label>
            <div class="valid-feedback">Price field is valid!</div>
            <div class="invalid-feedback">Price field cannot be blank!</div>
        </div>

                           <!-- <div class="col-md-12">
                              <input class="form-control" type="password" name="password" placeholder="Password" required>
                               <div class="valid-feedback">Password field is valid!</div>
                               <div class="invalid-feedback">Password field cannot be blank!</div>
                           </div> -->
                            <!-- <p id="ISBNcheck">Enter Details of a New Book</p> -->
                            <div class="form-button mt-3">
                                <button name="addBook" id="submit" type="submit" class="btn btn-primary">Update Details</button>
                            </div>
                        </form>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <?php include "footer.php";?>
</body>
</html>