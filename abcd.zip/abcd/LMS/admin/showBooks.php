<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>

<?php 
// include "function.php"
?>
<?php include "header.php"?>
<?php 
// $books = ShowAllBooks();
// echo "<pre>"; print_r($books); die;
$pdo = new PDO('mysql:host = localhost; port=3306; dbname=LMS','root','');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);//sets the attribute of errormode to errormode exception
$src = $_GET['search'] ?? '';
$search = substr($src,0,3);
if($search){
        // $count = $count+1;
        $statement = $pdo->prepare('SELECT * FROM booklist WHERE subject LIKE :subject');
        $statement->bindValue(':subject', "%$search%");
}
else{
    $statement = $pdo->prepare('SELECT * FROM booklist ORDER BY sem ASC');
}

$statement->execute();
$books = $statement->fetchAll(PDO::FETCH_ASSOC);

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/table.css">
    <title>All Books Available</title>
</head>
<p><form>
        <center><div class="input-group mb-3" style="width:30%;">
            <input type="text" 
            class="form-control" 
            placeholder="Search for Subject" 
            name="search" value="">
            <button class="btn btn-outline-secondary" type="submit">Search</button>
        </div></center>
    </form></p>
<body class="hm-gradient">
    
    <main>
        <!--MDB Tables-->
        <div class="container mt-4">

            <div class="text-center darken-grey-text mb-4">
                <h1 class="font-bold mt-4 mb-3 h5">Showing All Books (semester wise) Added to Library</h1>
            </div>
            <p id="demo"></p>
            <div class="card mb-4">
                <div class="card-body">
                    <!-- Grid row -->
                    
                    <!-- Grid row -->
                    <!--Table-->
                    
                    <table class="table table-bordered" id="myTable">
                        <!--Table head-->
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>ISBN</th>
                                <th>Semester</th>
                                <th>Subject</th>
                                <th>Book Name</th>
                                <th>Author Name</th>
                                <th>No of Pages</th>
                                <th>About Book</th>
                                <th>Publisher</th>
                                <th>Publishing Year</th>
                                <th>Price</th>
                                <th colspan="2">Action</th>
                            </tr>
                        </thead>
                        <!--Table head-->
                        <!--Table body-->
                        <tbody>
                            <?php if($books){
                                foreach($books as $key => $value){?>
                                
                                    <tr>
                                        <th scope="row"><?php echo ($key+1); ?></th>
                                        <td><?php echo $value['ISBN'] ?></td>
                                        <td><?php echo $value['sem'] ?></td>
                                        <td><?php echo $value['subject'] ?></td>
                                        <td><?php echo $value['name'] ?></td>
                                        <td><?php echo $value['author'] ?></td>
                                        <td><?php echo $value['pages'] ?></td>
                                        <td><?php echo $value['description'] ?></td>
                                        <td><?php echo $value['publisher'] ?></td>
                                        <td><?php echo $value['pub_year'] ?></td>
                                        <td><?php echo $value['price'] ?></td>
                                        <td> <a href="EditBook.php?id=<?php echo $value['ISBN'];?>" class="btn btn-sm btn-outline-primary">Edit</a> </td>
                                        <td> <a href="deleteBook.php?id=<?php echo $value['ISBN']; ?>" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-outline-danger">Delete</a> </td>
                                        <!-- <script type="text/javascript">
                                        function myFunction(){
                                            let text="Are you sure to delete ?";
                                            if(confirm(text)==true){
                                                text="You Deleted";
                                                // document.location=deleteBook.php?id=<?php echo $value['ISBN'];?>;
                                            }
                                            else{
                                                text="You Cancelled";
                                            }
                                            document.getElementById("demo").innerHTML = text;
                                        }
                                        </script> -->
                                    </tr> <?php 
                                }
                            }?>
                        </tbody>
                        <!--Table body-->
                    </table>
                    <!--Table-->
                </div>
            </div>                 
    </main>
    <!-- <center><?php if(isset($_GET['msg'])){
                            echo "<br>".$_GET['msg'];
                        }?></b></center> -->
    
    <!-- <?php include "footer.php";?> -->
</body>
</html>

<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#myTable').DataTable();
} );
</script>