<?php include "function.php";

$id=$_POST['bookid'];
$dt = date("Y-m-d");
// echo $dt;
$x = renew($id,$dt);
if($x){
    echo "Issue Date Updated..<br>";
    echo "<h4><a href='index.php'>Go Back</a>";
}
?>