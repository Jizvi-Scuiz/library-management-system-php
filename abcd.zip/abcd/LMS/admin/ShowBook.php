<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>

<?php include "function.php"?>
<!-- <?php include "header.php"?> -->
<?php 
$id = $_POST['bookid'];
$x = ShowBooks($id);
$y = FetchDate($id);
// echo "<pre>"; print_r($y); die;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->
    <title>Document</title>
</head>
<body>

<div class="container">
            <!-- <h2>Basic Table</h2> -->
            <!-- <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>             -->
                <table class="table">
                    <thead>
                        <tr>
                            <th>ISBN</th>
                            <th>Book Name</th>
                            <th>Author</th>
                            <th>About Book</th>
                            <th>Publisher</th>
                            <th>Issue Date</th>
                            <th>Fine</th>
                        </tr>
                    </thead>
                <tbody>
                    <?php if($x){
                        foreach($x as $key => $value){ ?>
                            <tr>
                                <td><?php echo $value['ISBN']?></td>
                                <td><?php echo $value['name']?></td>
                                <td><?php echo $value['author']?></td>
                                <td><?php echo $value['description']?></td>
                                <td><?php echo $value['publisher']?></td>
                                <td><?php echo $y['iDate'] ?></td>
                                <td><?php 
                                    $date1 = date_create($y['iDate']);
                                    $fine = calFine($date1);                                    
                                    echo "Rs. ".$fine."/-";
                                ?></td>
                            </tr><?php 
    
                        }
                    }?>
                </tbody>
             </table>
        </div>
</body>
</html>