<?php 
include "connect.php";
?>
<?php 
function checkall($isbn, $sem, $sub){
    $que = "SELECT ISBN, sem, subject FROM `booklist` WHERE ISBN=$isbn AND sem=$sem AND subject='$sub' ";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;
}
function isbnCheck($isbn){
    $que = "SELECT ISBN FROM `booklist` WHERE ISBN=$isbn ";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;
}
function addBook($isbn,$sem,$sub,$name,$author,$page,$description,$pbyr,$price,$publisher){
    // echo $isbn."<br>".$sem."<br>".$sub."<br>".$name."<br>".$author."<br>".$page."<br>".$description."<br>".$publisher."<br>".$pbyr."<br>".$price."<br>";
    $que = "INSERT INTO `booklist` (`ISBN`, `sem`, `subject`, `name`, `author`, `pages`, `description`, `pub_year`, `price`, `publisher`) 
            VALUES ('$isbn', '$sem', '$sub', '$name', '$author', '$page', '$description', '$pbyr', '$price', '$publisher')";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    return $res;
}
function ShowAllBooks(){
    $que = "SELECT * FROM `booklist` ORDER BY sem ASC";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;
}

function deleteBooks($id){
    $query = "DELETE FROM booklist WHERE ISBN='$id'";
    $conn = db_conn();
    $res = mysqli_query($conn,$query);
    return $res;
}

function GetRecords($id){
    $que = "SELECT * FROM `records` WHERE student_id='$id' ";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;
}
?>

<?php 
function getClassSemester($id){
    $que = "SELECT semester, subject FROM student WHERE student_id=$id";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data[0];
}

function GetBooks($sem,$sub){
    $que = "SELECT book_id, ISBN, name, author, description FROM booklist WHERE sem=$sem AND subject='$sub'";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;
}
function EditBooks($id){
    $que = "SELECT sem, subject, name, author, pages, description, pub_year, price, publisher FROM booklist WHERE ISBN='$id'";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data[0];
}

function checkIfIssued($id){
    $que = "SELECT book_id FROM `records` WHERE 1";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    $flag=0;
    // echo "<pre>"; print_r($data[0]);die;
    foreach($data as $key => $value){
        if($value['book_id']==$id){
            $flag++;
        }
    }
    return $flag;
}
function GetPhone($studtid){
    $que = "SELECT phone FROM student WHERE student_id = '$studtid'";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data[0];
}

function BookIssued($studentid,$phn,$isbn,$bookid,$date){
    $query = "INSERT INTO `records` (`student_id`, `phone_no`, `book_isbn`, `book_id`,`iDate`) 
                VALUES ('$studentid', '$phn', '$isbn', '$bookid', '$date')";
    $conn = db_conn();
    $res = mysqli_query($conn,$query);
    return $res;
}

function idValidate($id){
    $que = "SELECT student_id FROM student";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    $flag=0;
    foreach($data as $key => $value){
        if($value['student_id']==$id){
            $flag+=1;
            break;
        }
    }
    // echo $flag;die;
    return $flag;
    // echo "<pre>"; print_r($data); die;
}

function GetIssuedBooks($id){
    $que = "SELECT * FROM `records` WHERE student_id='$id'";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;
}

function deleteRecord($id){
    $que = "DELETE FROM records WHERE book_id='$id'";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    return 1;
}
function renew($id,$dt){
    // echo $dt;
    $que = "UPDATE `records` SET `iDate` = '$dt' WHERE `records`.`book_id` = $id";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    // echo "<h4><a href='index.php'>Issue Renewed<br>Go Back</a>";
    return $res;
}
function ShowBooks($id){
    $que = "SELECT * FROM `booklist` WHERE book_id='$id'";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;
}

function UpdBook($isbn,$sem,$sub,$name,$author,$page,$description,$pbyr,$price,$publisher){
    $que = "UPDATE `booklist` SET `sem` = '$sem', `subject` = '$sub', `name` = '$name', 
    `author` = '$author', `pages` = '$page', `description` = '$description', `pub_year` = '$pbyr',
     `price` = '$price', `publisher` = '$publisher' WHERE `booklist`.`ISBN` = $isbn";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    return $res;
}
function ShowStudent($id){
    $que = "SELECT * FROM `student` WHERE student_id='$id'";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data[0];
}
function FetchDate($id){
    $que = "SELECT iDate FROM records WHERE book_id='$id'";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data[0];
}

function calFine($date1){
    $x= date("Y-m-d");
    $date2 = date_create($x);
    $fine = 0; 
    // echo $date1; die;
    $diff=date_diff($date1, $date2);
    $dtdiff = number_format($diff->format("%a"));
    if($dtdiff>14){
        $fine=($dtdiff - 14) * 3;
    }
    return $fine;
}
function getReq(){
    // echo $book_id; die;
    $que = "SELECT * FROM requests WHERE 1";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    if($res){
        $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
        return $data;
    }
}

function deleteReq($id){
        $que = "DELETE FROM `requests` WHERE `requests`.`book_id` = '$id'";
        $conn = db_conn();
        $res = mysqli_query($conn,$que);
        return $res;
}
function ifReq($book_id){
    // echo $book_id; die;
    $que = "SELECT * FROM requests WHERE book_id = '$book_id'";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    if($data){
        return 1;
    }else{
        return 0;
    }
}

function GetRec(){
    $que = "SELECT * FROM `records` ORDER BY `iDate` ASC";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;    
}

function getIsbn($id)
{
    $que = "SELECT ISBN FROM `booklist` WHERE book_id = $id";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;  
}

function no_of_books($stid){
    $que = "SELECT student_id FROM records WHERE student_id = $stid";
    $conn = db_conn();
    $res = mysqli_query($conn,$que);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    // echo "<pre>"; print_r($data); die;
    $flag = 0;
    foreach ($data as $key => $value){
        $flag++;
    }  
    if($flag<3){
        return 1;
    }
    else{
        return 0;
    }

}

?>

