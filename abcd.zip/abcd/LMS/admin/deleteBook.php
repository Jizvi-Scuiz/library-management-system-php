<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>

<?php include "function.php"?>

<?php 
$id = $_GET['id'];
$del = deleteBooks($id);
if($del){
    header('location:showBooks.php?msg=Delete Succesful');
}


?>
