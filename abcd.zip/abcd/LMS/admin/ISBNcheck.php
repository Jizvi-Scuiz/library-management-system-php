<?php session_start() ?>
<?php include 'function.php' ?>
<?php

if($_POST['bookid']){
    $isbn = $_POST['bookid'];
    $_SESSION['isbn'] = $isbn;
}
?>