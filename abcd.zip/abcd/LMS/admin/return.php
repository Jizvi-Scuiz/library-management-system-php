<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>

<?php include "function.php"?>
<?php include "header.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return or Renew</title>
</head>
<body><center><br>
    <form action="" method="POST">
        <div class="form-group">
       <input class="form-cntrol" type="text" name="studid" placeholder="Enter Student ID">
        <button class="btn btn-primary" type="submit" name="submit">Search</button>
        </div>
        
    </form>
    <p id="show"></p>
    <br>
</center>
</body>
</html>

<?php

if(isset($_POST['submit'])){
    $id = $_POST['studid'];
    if(idValidate($id)==0){
        header('location:index.php?msg=Invalid Student ID');
    }
    else{
        echo "<center><button type='button' class='btn btn-outline-info' id='btn' onclick='show($id)' onclick='hide()'>Click Here To Return Or Renew</button></center>";
    } 
}
echo "<br><br><br>";
include "footer.php";
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">
	function show(id1) {
		$.ajax({
	        url: "rern.php",
	        method: "POST",
	        datatype: "HTML",
	        data: {
                studid:id1
	        },
	        success: function(x){
	          $("#show").html(x);
              $("#btn").hide();
	        }
	    });	
	}
</script>