<?php include "function.php"?>
<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>



<?php include "header.php"?>
<?php 
$id = $_POST['studentID'];


?>
<?php 

$records = GetRecords($id);
$student=ShowStudent($id);
$x=idValidate($id);
// echo "<pre>"; print_r($records); die;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="css/table.css">
    <title>Records</title>
</head>
<body>
    <?php 
    if(idValidate($id)==0){
        header('location:search.php?msg=<h3>Sorry <br>No Books Found!!<br> Please try a different ID </h3> ');
    }
    ?>    
    <center>  <h4><b>Student ID: <?php echo $id;?> <br> 
        </b></h4> 
        <h6><b>Name: <?php echo $student['name']; ?><br> 
        Semester: <?php echo $student['semester']; ?><br> 
        Subject: <?php echo $student['subject']; ?><br> 
        Phone: <?php echo $student['phone']; ?><br> 
        </b></h6> 
        <?php
        $flag=0; 
        if($records){
            echo "<h5><b>ISBN of Books Issued to the Student</b></h5>";
            echo"<h6>Click to display details</h6>";
            foreach($records as $key=>$value){ 
                $flag+=1;    ?>
                <h5> <button type="button" onclick="aboutBook(<?php echo $value['book_id']; ?>)">
                    <?php echo $value['book_isbn']; ?><br></button> 
                </h5>
            <?php }
        }
        if($flag<3){?>
            <div class="xyz" id="books" >
                <h4><br> <b> Available Books for The Student: </b></h4>
                <?php 
                $info = getClassSemester($id);
                $sem=$info['semester'];
                $sub = $info['subject'];
                $show = GetBooks($sem,$sub);
                // echo "<pre>"; print_r($show); die;
                ?>
                <div class="container">
                <!-- <h2>Basic Table</h2> -->
                <!-- <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>             -->
                    <table class="table">
                        <thead>
                            <tr>
                                
                                <th>ISBN</th>
                                <th>Book Name</th>
                                <th>Author</th>
                                <th>About Book</th>
                                <th>Issue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($show){
                                foreach($show as $key=>$value){ 
                                    $x = checkIfIssued($value['book_id']);
                                    if(!$x){
                                    ?>
                                    <tr id="book">
                                        <td><?php echo $value['ISBN']?></td>
                                        <td><?php echo $value['name']?></td>
                                        <td><?php echo $value['author']?></td>
                                        <td><?php echo $value['description']?></td>
                                        <td> <button class="btn btn-primary" name="button" id="btn1" onclick="issue(<?php echo $value['book_id']; ?>)">Issue</button> </td>
                                    </tr><?php 
                                    }
                                    else{
                                        continue;
                                    }
                                }
                            }?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php 
        }
        else{
            echo "<h3>You Cannot Issue More than 3 books At a time</h3>";
            echo "<h5><a href='return.php'>Return Book</a></h5>";
        }?>
        <p id="show"></p>
        <p id="issued"> </p>
<?php include "footer.php";?>
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">
	function issue(id1) {
		$.ajax({
	        url: "issued.php",
	        method: "POST",
	        datatype: "HTML",
	        data: {
	          bookid:id1,
              studid:<?php echo $id ?>
            //   studid:$id
	        },
	        success: function(x){
	          $("#issued").html(x);
              $("#books").hide();
	        }
	    });	
	}
</script>
<script type="text/javascript">
	function aboutBook(id1) {
		$.ajax({
	        url: "ShowBook.php",
	        method: "POST",
	        datatype: "HTML",
	        data: {
	          bookid:id1
            //   studid:$id
	        },
	        success: function(x){
	          $("#show").html(x);
	        }
	    });	
	}
</script>