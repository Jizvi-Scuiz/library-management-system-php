<?php include 'function.php' ?>
<?php
$id = $_POST['studid'];
$x = GetIssuedBooks($id);
// echo "<pre>";print_r($x);die;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return or Renew</title>
</head>
<body>
<div class="container">
            <!-- <h2>Basic Table</h2> -->
            <!-- <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>             -->
                <table class="table">
                    <thead>
                        <tr>
                            <th>ISBN</th>
                            <th colspan="2"></th>
                            <th>Issue Date</th>
                            <th>Fine</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php if($x){
                            foreach($x as $key=>$value){ 
                                // $x = checkIfIssued($value['ISBN']);
                                ?>
                                <tr>
                                    <td><?php echo $value['book_isbn']?></td>
                                    <td> <button type="button" class="btn btn-outline-primary" name="btn2" id="btn2" onclick="retrn(<?php echo $value['book_id']?>)">Return</button> </td>
                                    <td> <button type="button" class="btn btn-outline-success" name="btn3" id="btn3" onclick="Renew(<?php echo $value['book_id']?>)">Renew</button> </td>
                                    <td> <?php 
                                    $y = FetchDate($value['book_id']); 
                                    echo $y['iDate'];?> </td>
                                    <td> <?php 
                                    $date1 = date_create($y['iDate']);
                                    $fine = calFine($date1);                                    
                                    echo "Rs. ".$fine."/-";
                                    ?> 
                                    </td>
                                </tr><?php 

                            }
                        }?>
                    </tbody>
                </table>
                <p id="show"></p>
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">
	function retrn(id1) {
		$.ajax({
	        url: "retrn.php",
	        method: "POST",
	        datatype: "HTML",
	        data: {
                bookid:id1
	        },
            success: function(x){
	          $("#show").html(x);
	        }
	    });	
	}
</script>
<script type="text/javascript">
	function Renew(id1) {
		$.ajax({
	        url: "renew.php",
	        method: "POST",
	        datatype: "HTML",
	        data: {
                bookid:id1
	        },
            success: function(x){
	          $("#show").html(x);
	        }
	    });	
	}
</script>