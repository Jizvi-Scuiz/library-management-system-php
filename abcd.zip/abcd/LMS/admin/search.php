<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>

<?php include "function.php"?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/search.css">
    <title>Book Issue</title>
</head>
<body>
<div id="cover">
  <form method="POST" action="showrecords.php">
    <div class="tb">
      <div class="td"><input type="text" name="studentID" placeholder="Enter Student ID" required></div>
      <div class="td" id="s-cover">
        <button type="submit" name="submit">
          <div id="s-circle"></div>
          <span></span>
        </button>
      </div>
    </div>
  </form>
</div>    
<center><?php if(isset($_GET['msg'])){
                            echo "<br><h4>".$_GET['msg']."</h4>";
                        }?></b></center>
    
    
</body>
</html>


