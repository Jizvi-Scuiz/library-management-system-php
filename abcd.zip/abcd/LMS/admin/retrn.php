<?php include "function.php";

$id = $_POST['bookid'];
$x = deleteRecord($id);
if($x){
    echo "Book Returned..<br>";
    echo "<h4><a href='index.php'>Book Returned<br>Go Back</a>";
}
?>
