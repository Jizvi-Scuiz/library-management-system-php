<?php include "function.php" ?>
<?php session_start(); ?>
<?php 
    if(!isset($_SESSION['id'])){
        header('location:index.php?msg=Please Login First');
    }
    else{
        $user = $_SESSION['id'];
    }
    			// echo "<pre>"; print_r($_SESSION); die;
?>

<?php
// echo $_POST['bookid'];die;
$id = $_POST['bookid'];
$del = deleteReq($id);
if($del){
    echo "Request Removed";
}
?>