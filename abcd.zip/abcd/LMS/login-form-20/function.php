<?php 
include "connect.php";
?>
<?php 
function show_admin(){
    $query = "SELECT login_id FROM adminlogin WHERE 1";
    $conn = db_conn();
    $res = mysqli_query($conn,$query);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data;
}
?>
<?php 
function get_admin_data($id){
    $query = "SELECT * FROM adminlogin WHERE login_id = $id";
    $conn = db_conn();
    $res = mysqli_query($conn,$query);
    $data = mysqli_fetch_all($res,MYSQLI_ASSOC);
    return $data[0];
}
?>